`server_bin:*` contains "light" handlers, wich don't need sessions and other
heavy processing. Here we return static images, assets and, probably, binary
attachments.